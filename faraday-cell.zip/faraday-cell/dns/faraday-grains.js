'use strict';

const O_NEILL_WALL_SHEAR_FACTOR = 1.7009;

const GRAIN_MODEL = Object.freeze({
  name: 'grains on the floor of the Floquet-mode flow, leaving it when the drive exceeds gravity',
  equation: '(m_p + m_f/2) dv/dt = C_w 3 pi mu d (u(z) - v) + (3/2) m_f du/dt + F_friction (on the floor)',
  vertical: '(m_p + m_f/2) dw/dt = -(m_p - m_f)(g + a cos(omega_d t)) - 3 pi mu d w / f_perp(gap), while off the floor',
  wallDragFactor: O_NEILL_WALL_SHEAR_FACTOR,
  wallDragSource: "O'Neill (1968), sphere touching a plane wall in linear shear, Stokes flow",
  perpendicularDragSource: 'Bevan and Prieve (2000), J. Chem. Phys. 113, 1228: f_perp(h) = (6h^2 + 2ah)/(6h^2 + 9ah + 2a^2), '
    + 'h the gap and a the radius; it tends to Reynolds lubrication 6 pi mu a^2/h as h -> 0',
  fluidVelocityAt: 'the grain centre: d/2 above the floor while on it, d/2 + separation while off it',
  normalForce: '(m_p - m_f)(g + a cos(omega_d t)); the grain leaves the floor when it turns negative',
  liftOff: 'from the roughness gap, against the lubrication drag, which is what holds a grain to a wall in a liquid',
  landing: 'inelastic: the impact Stokes number St = rho_p d w/(9 mu) is recorded; rebound needs St above about 10 '
    + '(Gondret, Lance and Petit 2002, Phys. Fluids 14, 643)',
  friction: 'Coulomb: stick while |F| <= mu_s N, slide against mu_k N',
  streaming: 'steady streaming inside the floor Stokes layer, u = (1/w) Re[a(z/delta) (U.grad)U* + b(z/delta) (div U) U*], '
    + 'driven by the response-frequency component of the mode\'s flow taken 4 Stokes depths above the floor and carried '
    + 'to the floor with cosh(k z); edge values reproduce Schlichting (standing) and Longuet-Higgins 1953 (progressive)',
  neglected: ['Basset history force', 'lift', 'grain-grain contact', 'grain feedback on the fluid',
              'mean flow driven at the free surface and in the interior', 'higher harmonics of the mode in the streaming',
              'the vertical fluid velocity at the grain, which is second order in height at the no-slip floor',
              'the change of the parallel wall-drag factor with separation, held at its contact value; the separations reached are recorded',
              'the change of the added mass near the wall', 'rebound on landing']
});

function requirePositive(v, name){
  if (!(typeof v === 'number' && Number.isFinite(v) && v > 0))
    throw new RangeError(`${name} = ${v}: a finite positive number is required.`);
  return v;
}
function requireNonNegative(v, name){
  if (!(typeof v === 'number' && Number.isFinite(v) && v >= 0))
    throw new RangeError(`${name} = ${v}: a finite non-negative number is required.`);
  return v;
}

function floorFieldTable(o){
  const { mode, m, Td } = o;
  if (!mode || !mode.frames || !mode.grid) throw new TypeError(
    'floorFieldTable: a Floquet result with its periodic mode is required (floquetDisc with vector: true).');
  const amplitude = requirePositive(o.amplitude, 'amplitude');
  const zGrain = requirePositive(o.zGrain, 'zGrain');
  const { rf, zc } = mode.grid, nz = zc.length, nr = rf.length - 1;
  const frames = mode.frames, perDrive = frames.length - 1;
  const mu = mode.multiplier, sign = Math.sign(mu), mag = Math.abs(mu);
  if (!(mag > 0)) throw new RangeError('floorFieldTable: the multiplier is zero.');
  if (zGrain >= mode.grid.zf[nz]) throw new RangeError(
    `floorFieldTable: a grain centre ${zGrain} m above the floor is not inside the ${mode.grid.zf[nz]} m layer.`);
  let j1 = 0;
  while (j1 < nz && zc[j1] < zGrain) j1++;
  const zLo = j1 === 0 ? 0 : zc[j1 - 1], zHi = j1 >= nz ? zc[nz - 1] : zc[j1];
  if (j1 >= nz) throw new RangeError('floorFieldTable: the grain centre is above the top cell centre.');
  const wHi = (zGrain - zLo)/(zHi - zLo), wLo = 1 - wHi;
  const at = (arr, i, j) => j < 0 ? 0 : arr[i*nz + j];
  const responseSamples = sign < 0 ? 2*perDrive : perDrive;
  const period = sign < 0 ? 2*Td : Td;
  let etaPeak = 0;
  for (let k = 0; k < perDrive; k++){
    const damp = Math.pow(mag, -frames[k].t/Td);
    for (const e of frames[k].eta) etaPeak = Math.max(etaPeak, Math.abs(e)*damp);
  }
  if (!(etaPeak > 0)) throw new RangeError('floorFieldTable: the mode has no surface displacement.');
  const scale = amplitude/etaPeak;
  const faces = nr + 1;
  const knots = [];
  for (let rep = 0; rep < (sign < 0 ? 2 : 1); rep++)
    for (let k = 0; k < perDrive; k++){
      const f = frames[k], s = scale*(rep ? sign : 1)*Math.pow(mag, -f.t/Td);
      const u = new Float64Array(faces), v = new Float64Array(faces);
      for (let i = 0; i < faces; i++){
        u[i] = s*(wLo*at(f.u, i, j1 - 1) + wHi*at(f.u, i, j1));
        v[i] = s*(wLo*at(f.v, i, j1 - 1) + wHi*at(f.v, i, j1));
      }
      knots.push({ t: f.t + rep*Td, u, v });
    }
  const U = new Float64Array(responseSamples*faces), V = new Float64Array(responseSamples*faces);
  for (let k = 0, q = 0; k < responseSamples; k++){
    const t = k*period/responseSamples;
    while (q + 1 < knots.length && knots[q + 1].t <= t) q++;
    const a = knots[q], b = q + 1 < knots.length ? knots[q + 1]
      : { t: period, u: knots[0].u, v: knots[0].v };
    const w = (t - a.t)/(b.t - a.t);
    for (let i = 0; i < faces; i++){
      U[k*faces + i] = (1 - w)*a.u[i] + w*b.u[i];
      V[k*faces + i] = (1 - w)*a.v[i] + w*b.v[i];
    }
  }
  const dts = period/responseSamples;
  const dU = new Float64Array(U.length), dV = new Float64Array(V.length);
  for (let k = 0; k < responseSamples; k++){
    const kp = (k + 1) % responseSamples, km = (k - 1 + responseSamples) % responseSamples;
    for (let i = 0; i < faces; i++){
      dU[k*faces + i] = (U[kp*faces + i] - U[km*faces + i])/(2*dts);
      dV[k*faces + i] = (V[kp*faces + i] - V[km*faces + i])/(2*dts);
    }
  }
  return { m, rf: Float64Array.from(rf), R: rf[nr], faces, samples: responseSamples, period,
           U, V, dU, dV, amplitude, zGrain, multiplier: mu, scale };
}

function streamingProfile(zeta){
  requireNonNegative(zeta, 'zeta');
  const e1 = Math.exp(-zeta), e2 = Math.exp(-2*zeta), c = Math.cos(zeta), s = Math.sin(zeta);
  const a = e1*s - (1 - e2)/4;
  const eRe = e1*c, eIm = e1*s;
  const pRe = eRe*zeta - eIm*(zeta + 1), pIm = eRe*(zeta + 1) + eIm*zeta;
  const bRe = -pRe/2 + (eIm - (1 - eRe))/2;
  const bIm = 0.5 - pIm/2 + ((1 - eRe) + eIm)/2 - (1 - e2)/4;
  return { a, bRe, bIm };
}

function streamingCoefficients(o){
  const { rf, m, omega } = o, prof = o.profile, faces = rf.length, nr = faces - 1;
  const Ar = o.A.re, Ai = o.A.im, Br = o.B.re, Bi = o.B.im;
  const PrCC = new Float64Array(faces), PrSS = new Float64Array(faces), PtSC = new Float64Array(faces);
  const QrCC = new Float64Array(faces), QtSC = new Float64Array(faces);
  const coef = (pRe, pIm, qRe, qIm) => (prof.a*pRe + prof.bRe*qRe - prof.bIm*qIm)/omega;
  const coefP = (pRe) => prof.a*pRe/omega;
  for (let i = 1; i < faces; i++){
    const r = rf[i];
    const il = Math.max(0, i - 1), ih = Math.min(nr, i + 1);
    const dr = rf[ih] - rf[il];
    const dAr = (Ar[ih] - Ar[il])/dr, dAi = (Ai[ih] - Ai[il])/dr;
    const dBr = (Br[ih] - Br[il])/dr, dBi = (Bi[ih] - Bi[il])/dr;
    const Dr = dAr + (Ar[i] + m*Br[i])/r, Di = dAi + (Ai[i] + m*Bi[i])/r;
    const AdA_re = Ar[i]*dAr + Ai[i]*dAi;
    const BA_re = Br[i]*Ar[i] + Bi[i]*Ai[i], BB = Br[i]*Br[i] + Bi[i]*Bi[i];
    const AdB_re = Ar[i]*dBr + Ai[i]*dBi;
    const DA_re = Dr*Ar[i] + Di*Ai[i], DA_im = Di*Ar[i] - Dr*Ai[i];
    const DB_re = Dr*Br[i] + Di*Bi[i], DB_im = Di*Br[i] - Dr*Bi[i];
    PrCC[i] = coefP(AdA_re);
    PrSS[i] = coefP(-(m*BA_re + BB)/r);
    PtSC[i] = coefP(AdB_re + (m*BB + BA_re)/r);
    QrCC[i] = coef(0, 0, DA_re, DA_im);
    QtSC[i] = coef(0, 0, DB_re, DB_im);
  }
  for (const arr of [PrCC, PrSS, PtSC, QrCC, QtSC]) arr[0] = m === 1 ? arr[1] : 0;
  return { PrCC, PrSS, PtSC, QrCC, QtSC };
}

function floorStreaming(o){
  const { mode, m, Td } = o;
  const amplitude = requirePositive(o.amplitude, 'amplitude');
  const nu = requirePositive(o.nu, 'nu'), k = requirePositive(o.k, 'k');
  const zGrain = requirePositive(o.zGrain, 'zGrain');
  const { rf, zc } = mode.grid, nz = zc.length, nr = rf.length - 1, faces = nr + 1;
  const frames = mode.frames, perDrive = frames.length - 1;
  const mu = mode.multiplier, sign = Math.sign(mu), mag = Math.abs(mu);
  const period = sign < 0 ? 2*Td : Td, omega = 2*Math.PI/period;
  const delta = Math.sqrt(2*nu/omega);
  const zTarget = 4*delta;
  let jo = 0;
  for (let j = 1; j < nz; j++) if (Math.abs(zc[j] - zTarget) < Math.abs(zc[jo] - zTarget)) jo = j;
  const zOuter = zc[jo];
  if (zOuter < 2*delta) throw new RangeError(
    `floorStreaming: the cell centre nearest 4 Stokes depths is ${zOuter} m, inside the ${delta} m layer.`);
  let etaPeak = 0;
  for (let q = 0; q < perDrive; q++){
    const damp = Math.pow(mag, -frames[q].t/Td);
    for (const e of frames[q].eta) etaPeak = Math.max(etaPeak, Math.abs(e)*damp);
  }
  const scale = amplitude/etaPeak/Math.cosh(k*zOuter);
  const Ar = new Float64Array(faces), Ai = new Float64Array(faces);
  const Br = new Float64Array(faces), Bi = new Float64Array(faces);
  const reps = sign < 0 ? 2 : 1;
  for (let rep = 0; rep < reps; rep++)
    for (let q = 0; q < perDrive; q++){
      const f0 = frames[q], f1 = frames[q + 1];
      const span = f1.t - f0.t;
      for (const [f, wgt] of [[f0, span/2], [f1, span/2]]){
        const t = f.t + rep*Td, s = scale*(rep ? sign : 1)*Math.pow(mag, -f.t/Td)*wgt*2/period;
        const cr = Math.cos(omega*t)*s, ci = -Math.sin(omega*t)*s;
        for (let i = 0; i < faces; i++){
          const u = f.u[i*nz + jo], v = f.v[i*nz + jo];
          Ar[i] += u*cr; Ai[i] += u*ci; Br[i] += v*cr; Bi[i] += v*ci;
        }
      }
    }
  const prof = streamingProfile(zGrain/delta);
  const { PrCC, PrSS, PtSC, QrCC, QtSC } = streamingCoefficients({ rf, m, A: { re: Ar, im: Ai }, B: { re: Br, im: Bi }, omega, profile: prof });
  return { m, rf: Float64Array.from(rf), faces, omega, delta, zOuter, zetaGrain: zGrain/delta,
           profile: prof, A: { re: Ar, im: Ai }, B: { re: Br, im: Bi },
           PrCC, PrSS, PtSC, QrCC, QtSC };
}

function streamingAt(S, r, th){
  const { rf, faces, m } = S, nr = faces - 1;
  let i = 0;
  while (i < nr - 1 && rf[i + 1] < r) i++;
  const w = Math.min(1, Math.max(0, (r - rf[i])/(rf[i + 1] - rf[i]))), lin = a => (1 - w)*a[i] + w*a[i + 1];
  const c = Math.cos(m*th), s = Math.sin(m*th);
  const ur = (lin(S.PrCC) + lin(S.QrCC))*c*c + lin(S.PrSS)*s*s;
  const ut = (lin(S.PtSC) + lin(S.QtSC))*s*c;
  return { ur, ut };
}

function mulberry32(seed){
  let a = seed >>> 0;
  return () => {
    a = (a + 0x6D2B79F5) >>> 0;
    let t = a;
    t = Math.imul(t ^ (t >>> 15), t | 1);
    t ^= t + Math.imul(t ^ (t >>> 7), t | 61);
    return ((t ^ (t >>> 14)) >>> 0)/4294967296;
  };
}

function columnTable(o){
  const T = o.table, mode = o.mode;
  if (!T || !mode) throw new TypeError('columnTable: the floor table and the mode it was built from are required.');
  const { m, Td } = o;
  const zc = mode.grid.zc, nz = zc.length;
  const L = nz + 1, faces = T.faces, samples = T.samples, plane = samples*faces;
  const z = new Float64Array(L);
  const U = new Float64Array(L*plane), V = new Float64Array(L*plane);
  const dU = new Float64Array(L*plane), dV = new Float64Array(L*plane);
  for (let j = 0; j < nz; j++){
    const Tj = floorFieldTable({ mode, m, Td, amplitude: T.amplitude, zGrain: zc[j] });
    if (Tj.samples !== samples || Tj.faces !== faces || Tj.period !== T.period) throw new RangeError(
      'columnTable: a level came out on a different sampling from the floor table.');
    z[j + 1] = zc[j];
    U.set(Tj.U, (j + 1)*plane); V.set(Tj.V, (j + 1)*plane);
    dU.set(Tj.dU, (j + 1)*plane); dV.set(Tj.dV, (j + 1)*plane);
  }
  let S = null;
  if (T.streaming){
    const SM = T.streaming;
    const PrCC = new Float64Array(L*faces), PrSS = new Float64Array(L*faces), PtSC = new Float64Array(L*faces);
    const QrCC = new Float64Array(L*faces), QtSC = new Float64Array(L*faces);
    for (let l = 0; l < L; l++){
      const prof = streamingProfile(z[l]/SM.delta);
      const c = streamingCoefficients({ rf: SM.rf, m: SM.m, A: SM.A, B: SM.B, omega: SM.omega, profile: prof });
      PrCC.set(c.PrCC, l*faces); PrSS.set(c.PrSS, l*faces); PtSC.set(c.PtSC, l*faces);
      QrCC.set(c.QrCC, l*faces); QtSC.set(c.QtSC, l*faces);
    }
    S = { PrCC, PrSS, PtSC, QrCC, QtSC };
  }
  return { L, z, U, V, dU, dV, streaming: S };
}

function perpendicularMobility(gap, a){
  return (6*gap*gap + 2*a*gap)/(6*gap*gap + 9*a*gap + 2*a*a);
}

function createGrains(o){
  const count = o.count;
  if (!(Number.isSafeInteger(count) && count > 0)) throw new RangeError(`count = ${count}: a positive whole number of grains.`);
  const R = requirePositive(o.R, 'R'), d = requirePositive(o.d, 'd');
  const rhoP = requirePositive(o.rhoP, 'rhoP'), rho = requirePositive(o.rho, 'rho');
  const mu = requirePositive(o.mu, 'mu');
  const muS = requireNonNegative(o.muS, 'muS'), muK = requireNonNegative(o.muK, 'muK');
  if (muK > muS) throw new RangeError(`muK = ${muK} exceeds muS = ${muS}: sliding friction above static friction.`);
  const g = requirePositive(o.g, 'g');
  const accel = requireNonNegative(o.accel, 'accel');
  const omegaD = requirePositive(o.omegaD, 'omegaD');
  if (!(rhoP > rho)) throw new RangeError(
    `rhoP = ${rhoP} kg/m^3 is not above the liquid's ${rho}: such a grain does not rest on the floor.`);
  if (d/2 >= R) throw new RangeError('the grain is wider than the cell.');
  const canFly = accel > g;
  let roughness = null;
  if (canFly){
    if (o.roughness === undefined) throw new RangeError(
      `peak acceleration ${accel} m/s^2 exceeds gravity ${g} m/s^2, so the grain leaves the floor once a cycle. `
      + 'Leaving a wall in a liquid is resisted by lubrication, which grows without bound as the gap closes; '
      + 'the gap a grain starts from is its surface roughness, and that has to be given (roughness, in metres).');
    roughness = requirePositive(o.roughness, 'roughness');
    if (roughness >= d/2) throw new RangeError(`roughness ${roughness} m is not below the grain radius ${d/2} m.`);
  }
  const vol = Math.PI*d*d*d/6;
  const mp = rhoP*vol, mf = rho*vol;
  const rMax = R - d/2;
  const x = new Float64Array(count), y = new Float64Array(count);
  if (o.positions){
    const px = o.positions.x, py = o.positions.y;
    if (!(px && py && px.length === count && py.length === count)) throw new RangeError('positions: one x and one y per grain.');
    for (let n = 0; n < count; n++){
      x[n] = px[n]; y[n] = py[n];
      if (!(Number.isFinite(x[n]) && Number.isFinite(y[n]))) throw new RangeError(`positions[${n}] is not finite.`);
      if (Math.hypot(x[n], y[n]) > rMax*(1 + 1e-12)) throw new RangeError(`positions[${n}] lies beyond R - d/2 = ${rMax} m.`);
    }
  } else {
    const rand = mulberry32(o.seed === undefined ? 1 : o.seed);
    for (let n = 0; n < count; n++){
      const r = rMax*Math.sqrt(rand()), th = 2*Math.PI*rand();
      x[n] = r*Math.cos(th); y[n] = r*Math.sin(th);
    }
  }
  const vx = new Float64Array(count), vy = new Float64Array(count);
  const stuck = new Uint8Array(count).fill(1);
  const air = new Uint8Array(count), sep = new Float64Array(count), vz = new Float64Array(count);
  const tLift = new Float64Array(count).fill(NaN);
  return { count, R, d, a: d/2, rMax, rhoP, rho, mu, muS, muK, g, accel, omegaD, canFly, roughness,
           mp, mf, M: mp + mf/2, C: O_NEILL_WALL_SHEAR_FACTOR*3*Math.PI*mu*d, Cz0: 3*Math.PI*mu*d,
           x, y, vx, vy, stuck, air, sep, vz, tLift, t: 0, steps: 0, slidSteps: 0,
           airSteps: 0, liftoffs: 0, landings: 0, maxSeparation: 0, maxImpactStokes: 0 };
}

function advanceGrains(G, T, tEnd, dt){
  requirePositive(dt, 'dt');
  if (!(tEnd >= G.t)) throw new RangeError(`tEnd = ${tEnd} is before the grains' time ${G.t}.`);
  const { faces, samples, period, rf, m } = T;
  const nr = faces - 1;
  const bins = 4096, binOf = new Int32Array(bins + 1);
  for (let b = 0, i = 0; b <= bins; b++){
    const r = rf[nr]*b/bins;
    while (i < nr - 1 && rf[i + 1] <= r) i++;
    binOf[b] = i;
  }
  const Ut = new Float64Array(faces), Vt = new Float64Array(faces);
  const dUt = new Float64Array(faces), dVt = new Float64Array(faces);
  const { x, y, vx, vy, stuck, air, sep, vz, tLift, C, M, mf, mp, muS, muK, g, accel, omegaD, rMax } = G;
  const buoyant = mp - mf;
  const SM = T.streaming || null;
  if (SM && (SM.faces !== faces || SM.m !== m || SM.rf.some((v, i) => v !== rf[i]))) throw new RangeError(
    'advanceGrains: the streaming field was built on a different grid or mode from the oscillatory table.');
  const col = G.canFly ? T.column : null;
  if (G.canFly && !col) throw new RangeError(
    'advanceGrains: these grains leave the floor, so the flow is needed at every height they reach: '
    + 'attach columnTable({ table, mode, m, Td }) to the table as table.column.');
  if (col && SM && !col.streaming) throw new RangeError(
    'advanceGrains: the floor table carries streaming but its column does not; build the column after attaching table.streaming.');
  const L = col ? col.L : 0, plane = samples*faces;
  const Uc = col ? new Float64Array(L*faces) : null, Vc = col ? new Float64Array(L*faces) : null;
  const dUc = col ? new Float64Array(L*faces) : null, dVc = col ? new Float64Array(L*faces) : null;
  const zTop = col ? col.z[L - 1] : 0, CSa = col ? col.streaming : null;
  const a = G.a, eps = G.roughness, Cz0 = G.Cz0, rhoP = G.rhoP, d = G.d, mu = G.mu;
  let nAir = 0;
  for (let n = 0; n < G.count; n++) nAir += air[n];
  const angular = (c, s) => {
    let cr = 1, ci = 0, br = c, bi = s, e = m;
    while (e > 0){
      if (e & 1){ const t = cr*br - ci*bi; ci = cr*bi + ci*br; cr = t; }
      const t = br*br - bi*bi; bi = 2*br*bi; br = t;
      e >>= 1;
    }
    ANG[0] = cr; ANG[1] = ci;
  };
  const ANG = new Float64Array(2);
  while (G.t < tEnd - 1e-15*period){
    const h = Math.min(dt, tEnd - G.t), tm = G.t + h/2;
    const ph = ((tm % period) + period) % period/period*samples;
    const k0 = Math.floor(ph) % samples, k1 = (k0 + 1) % samples, w1 = ph - Math.floor(ph), w0 = 1 - w1;
    for (let i = 0; i < faces; i++){
      Ut[i] = w0*T.U[k0*faces + i] + w1*T.U[k1*faces + i];
      Vt[i] = w0*T.V[k0*faces + i] + w1*T.V[k1*faces + i];
      dUt[i] = w0*T.dU[k0*faces + i] + w1*T.dU[k1*faces + i];
      dVt[i] = w0*T.dV[k0*faces + i] + w1*T.dV[k1*faces + i];
    }
    const geff = g + accel*Math.cos(omegaD*tm);
    const N = buoyant*geff;
    const stickLimit = muS*N, slideFriction = muK*N;
    const lifting = G.canFly && N < 0;
    if (col && (lifting || nAir > 0)){
      for (let l = 0; l < L; l++){
        const o0 = l*plane + k0*faces, o1 = l*plane + k1*faces, oc = l*faces;
        for (let i = 0; i < faces; i++){
          Uc[oc + i] = w0*col.U[o0 + i] + w1*col.U[o1 + i];
          Vc[oc + i] = w0*col.V[o0 + i] + w1*col.V[o1 + i];
          dUc[oc + i] = w0*col.dU[o0 + i] + w1*col.dU[o1 + i];
          dVc[oc + i] = w0*col.dV[o0 + i] + w1*col.dV[o1 + i];
        }
      }
    }
    for (let n = 0; n < G.count; n++){
      const px = x[n], py = y[n];
      const r = Math.hypot(px, py);
      const b = Math.min(bins, Math.floor(r/rf[nr]*bins));
      let i = binOf[b];
      while (i < nr - 1 && rf[i + 1] < r) i++;
      while (i > 0 && rf[i] > r) i--;
      const wR = (r - rf[i])/(rf[i + 1] - rf[i]), wL = 1 - wR;
      const c = r > 0 ? px/r : 1, s = r > 0 ? py/r : 0;
      angular(c, s);
      const cm = ANG[0], sm = ANG[1];
      if (!air[n] && lifting){
        air[n] = 1; sep[n] = 0; vz[n] = 0; stuck[n] = 0; tLift[n] = G.t;
        nAir++; G.liftoffs++;
      }
      if (air[n]){
        const zc = a + sep[n];
        if (!(zc < zTop)) throw new RangeError(
          `advanceGrains: a grain's centre reached ${zc} m above the floor, above the top cell centre ${zTop} m `
          + 'where the column is tabulated. Refusing rather than inventing the flow there.');
        let l = 0;
        while (l < L - 2 && col.z[l + 1] <= zc) l++;
        const wz = (zc - col.z[l])/(col.z[l + 1] - col.z[l]), wz0 = 1 - wz;
        const p00 = l*faces + i, p01 = p00 + 1, p10 = p00 + faces, p11 = p10 + 1;
        const c00 = wz0*wL, c01 = wz0*wR, c10 = wz*wL, c11 = wz*wR;
        const ur = c00*Uc[p00] + c01*Uc[p01] + c10*Uc[p10] + c11*Uc[p11];
        const ut = c00*Vc[p00] + c01*Vc[p01] + c10*Vc[p10] + c11*Vc[p11];
        const ar = c00*dUc[p00] + c01*dUc[p01] + c10*dUc[p10] + c11*dUc[p11];
        const at = c00*dVc[p00] + c01*dVc[p01] + c10*dVc[p10] + c11*dVc[p11];
        let vr = ur*cm, vt = ut*sm;
        const qr = ar*cm, qt = at*sm;
        if (CSa){
          const prcc = c00*(CSa.PrCC[p00] + CSa.QrCC[p00]) + c01*(CSa.PrCC[p01] + CSa.QrCC[p01])
                     + c10*(CSa.PrCC[p10] + CSa.QrCC[p10]) + c11*(CSa.PrCC[p11] + CSa.QrCC[p11]);
          const prss = c00*CSa.PrSS[p00] + c01*CSa.PrSS[p01] + c10*CSa.PrSS[p10] + c11*CSa.PrSS[p11];
          const ptsc = c00*(CSa.PtSC[p00] + CSa.QtSC[p00]) + c01*(CSa.PtSC[p01] + CSa.QtSC[p01])
                     + c10*(CSa.PtSC[p10] + CSa.QtSC[p10]) + c11*(CSa.PtSC[p11] + CSa.QtSC[p11]);
          vr += prcc*cm*cm + prss*sm*sm;
          vt += ptsc*sm*cm;
        }
        const ufx = vr*c - vt*s, ufy = vr*s + vt*c;
        const afx = qr*c - qt*s, afy = qr*s + qt*c;
        const fx = C*ufx + 1.5*mf*afx, fy = C*ufy + 1.5*mf*afy;
        vx[n] = (M*vx[n] + h*fx)/(M + h*C);
        vy[n] = (M*vy[n] + h*fy)/(M + h*C);
        const Cz = Cz0/perpendicularMobility(eps + sep[n], a);
        const w = (M*vz[n] - h*N)/(M + h*Cz);
        const sNew = sep[n] + h*w;
        x[n] += vx[n]*h; y[n] += vy[n]*h;
        G.airSteps++;
        if (sNew <= 0){
          const St = rhoP*d*Math.abs(w)/(9*mu);
          if (St > G.maxImpactStokes) G.maxImpactStokes = St;
          sep[n] = 0; vz[n] = 0; air[n] = 0; stuck[n] = 0;
          nAir--; G.landings++;
        } else {
          sep[n] = sNew; vz[n] = w;
          if (sNew > G.maxSeparation) G.maxSeparation = sNew;
        }
      } else {
        const ur = wL*Ut[i] + wR*Ut[i + 1], ut = wL*Vt[i] + wR*Vt[i + 1];
        const ar = wL*dUt[i] + wR*dUt[i + 1], at = wL*dVt[i] + wR*dVt[i + 1];
        let vr = ur*cm, vt = ut*sm;
        const qr = ar*cm, qt = at*sm;
        if (SM){
          vr += (wL*(SM.PrCC[i] + SM.QrCC[i]) + wR*(SM.PrCC[i + 1] + SM.QrCC[i + 1]))*cm*cm
              + (wL*SM.PrSS[i] + wR*SM.PrSS[i + 1])*sm*sm;
          vt += (wL*(SM.PtSC[i] + SM.QtSC[i]) + wR*(SM.PtSC[i + 1] + SM.QtSC[i + 1]))*sm*cm;
        }
        const ufx = vr*c - vt*s, ufy = vr*s + vt*c;
        const afx = qr*c - qt*s, afy = qr*s + qt*c;
        const fx = C*ufx + 1.5*mf*afx, fy = C*ufy + 1.5*mf*afy;
        if (stuck[n]){
          const fs = Math.hypot(fx, fy);
          if (fs <= stickLimit) continue;
          stuck[n] = 0;
          const nx = vx[n] = (h*(fx - slideFriction*fx/fs))/(M + h*C);
          const ny = vy[n] = (h*(fy - slideFriction*fy/fs))/(M + h*C);
          x[n] += nx*h; y[n] += ny*h;
        } else {
          const sp = Math.hypot(vx[n], vy[n]);
          const dx = sp > 0 ? vx[n]/sp : 0, dy = sp > 0 ? vy[n]/sp : 0;
          const nvx = (M*vx[n] + h*(fx - slideFriction*dx))/(M + h*C);
          const nvy = (M*vy[n] + h*(fy - slideFriction*dy))/(M + h*C);
          if (sp > 0 && nvx*vx[n] + nvy*vy[n] <= 0){
            vx[n] = 0; vy[n] = 0;
            const fsNow = Math.hypot(fx, fy);
            stuck[n] = fsNow <= stickLimit ? 1 : 0;
          } else { vx[n] = nvx; vy[n] = nvy; }
          x[n] += vx[n]*h; y[n] += vy[n]*h;
          G.slidSteps++;
        }
      }
      const rr = Math.hypot(x[n], y[n]);
      if (rr > rMax){
        const ex = x[n]/rr, ey = y[n]/rr;
        x[n] = ex*rMax; y[n] = ey*rMax;
        const out = vx[n]*ex + vy[n]*ey;
        if (out > 0){ vx[n] -= out*ex; vy[n] -= out*ey; }
      }
    }
    G.t += h; G.steps++;
  }
  return G;
}

function driftMap(o){
  const T = o.table, m = T.m;
  const nr = o.nr === undefined ? 64 : o.nr, nthIn = o.nth === undefined ? 16 : o.nth;
  const settle = o.settle === undefined ? 12 : o.settle, measure = o.measure === undefined ? 12 : o.measure;
  const P = o.stepsPerPeriod === undefined ? 256 : o.stepsPerPeriod;
  for (const [k, v, lo] of [['nr', nr, 2], ['nth', nthIn, 4], ['settle', settle, 0], ['measure', measure, 1], ['stepsPerPeriod', P, 8]])
    if (!Number.isSafeInteger(v) || v < lo) throw new RangeError(`driftMap: ${k} = ${v}: a whole number of at least ${lo} is required.`);
  const sign = Math.sign(T.multiplier);
  const M = m === 0 ? 0 : (sign < 0 ? 2*m : m), nth = m === 0 ? 1 : nthIn;
  const rMax = o.R - o.d/2;
  const xs = new Float64Array(nr*nth), ys = new Float64Array(nr*nth);
  const dirC = new Float64Array(nr*nth), dirS = new Float64Array(nr*nth);
  for (let i = 0; i < nr; i++){
    const r = rMax*i/(nr - 1);
    for (let j = 0; j < nth; j++){
      const th = nth === 1 ? 0 : Math.PI*j/((nth - 1)*M);
      const c = Math.cos(th), s = Math.sin(th), n = i*nth + j;
      xs[n] = r*c; ys[n] = r*s; dirC[n] = c; dirS[n] = s;
    }
  }
  const probe = createGrains({ ...o, count: nr*nth, positions: { x: xs, y: ys } });
  const period = T.period, dt = period/P;
  advanceGrains(probe, T, settle*period, dt);
  const bx = Float64Array.from(probe.x), by = Float64Array.from(probe.y);
  advanceGrains(probe, T, (settle + measure)*period, dt);
  const span = measure*period;
  const UR = new Float64Array(nr*nth), UT = new Float64Array(nr*nth), Gm = new Float64Array(nr*nth);
  const Cj = Float64Array.from({ length: nth }, (_, j) => nth === 1 ? 1 : Math.cos(Math.PI*j/(nth - 1)));
  const Sj = Float64Array.from({ length: nth }, (_, j) => nth === 1 ? 0 : Math.sin(Math.PI*j/(nth - 1)));
  for (let i = 1; i < nr; i++) for (let j = 0; j < nth; j++){
    const n = i*nth + j, c = dirC[n], s = dirS[n];
    const ux = (probe.x[n] - bx[n])/span, uy = (probe.y[n] - by[n])/span;
    UR[n] = ux*c + uy*s;
    UT[n] = uy*c - ux*s;
    if (nth > 1 && j > 0 && j < nth - 1) Gm[n] = UT[n]/Sj[j];
  }
  if (nth > 1) for (let i = 1; i < nr; i++){
    for (const [edge, ja, jb] of [[0, 1, 2], [nth - 1, nth - 2, nth - 3]]){
      const ga = Gm[i*nth + ja], gb = Gm[i*nth + jb];
      Gm[i*nth + edge] = ga + (ga - gb)*(Cj[edge] - Cj[ja])/(Cj[ja] - Cj[jb]);
    }
  }
  return { m, M, nr, nth, rMax, dr: rMax/(nr - 1), UR, UT, G: Gm, C: Cj, period, settle, measure, stepsPerPeriod: P,
           probes: { before: { x: bx, y: by }, after: { x: Float64Array.from(probe.x), y: Float64Array.from(probe.y) } },
           flight: { canFly: probe.canFly, liftoffs: probe.liftoffs, landings: probe.landings, airSteps: probe.airSteps,
                     maxSeparation: probe.maxSeparation, maxImpactStokes: probe.maxImpactStokes, radius: probe.a } };
}

function driftAtPoint(Dm, x, y, out){
  const r2 = x*x + y*y;
  if (r2 === 0){ out[0] = 0; out[1] = 0; return; }
  const r = Math.sqrt(r2), c0 = x/r, s0 = y/r;
  let wc = 1, ws = 0;
  if (Dm.nth > 1){
    let cr = 1, ci = 0, br = c0, bi = s0, e = Dm.M;
    while (e > 0){
      if (e & 1){ const t = cr*br - ci*bi; ci = cr*bi + ci*br; cr = t; }
      const t = br*br - bi*bi; bi = 2*br*bi; br = t;
      e >>= 1;
    }
    wc = cr; ws = ci;
  }
  const fr = r/Dm.dr;
  let i = Math.floor(fr);
  if (i > Dm.nr - 2) i = Dm.nr - 2;
  const wr = fr - i, wr0 = 1 - wr;
  let ur, g = 0;
  if (Dm.nth > 1){
    let lo = 0, hi = Dm.nth - 2;
    while (lo < hi){ const mid = (lo + hi + 1) >> 1; if (Dm.C[mid] >= wc) lo = mid; else hi = mid - 1; }
    const j = lo;
    const wt = (Dm.C[j] - wc)/(Dm.C[j] - Dm.C[j + 1]), wt0 = 1 - wt;
    const A = Dm.UR, B = Dm.G, nth = Dm.nth;
    const a00 = i*nth + j, a01 = a00 + 1, a10 = a00 + nth, a11 = a10 + 1;
    ur = wr0*(wt0*A[a00] + wt*A[a01]) + wr*(wt0*A[a10] + wt*A[a11]);
    g = wr0*(wt0*B[a00] + wt*B[a01]) + wr*(wt0*B[a10] + wt*B[a11]);
  } else ur = wr0*Dm.UR[i] + wr*Dm.UR[i + 1];
  const ut = ws*g;
  out[0] = ur*c0 - ut*s0;
  out[1] = ur*s0 + ut*c0;
}

function createSand(o){
  const Dm = o.drift, count = o.count;
  if (!Dm || !Dm.UR) throw new TypeError('createSand: a drift map is required.');
  if (!Number.isSafeInteger(count) || count < 1) throw new RangeError(`count = ${count}: a positive whole number of grains.`);
  const x = new Float64Array(count), y = new Float64Array(count);
  if (o.positions){
    if (o.positions.x.length !== count || o.positions.y.length !== count) throw new RangeError('positions: one x and one y per grain.');
    x.set(o.positions.x); y.set(o.positions.y);
  } else {
    const rand = mulberry32(o.seed === undefined ? 1 : o.seed);
    for (let n = 0; n < count; n++){
      const r = Dm.rMax*Math.sqrt(rand()), th = 2*Math.PI*rand();
      x[n] = r*Math.cos(th); y[n] = r*Math.sin(th);
    }
  }
  const out = new Float64Array(2), rMax2 = Dm.rMax*Dm.rMax;
  const sand = { count, x, y, t: 0,
    advect(nSteps, dt){
      requirePositive(dt, 'dt');
      for (let k = 0; k < nSteps; k++){
        for (let n = 0; n < count; n++){
          driftAtPoint(Dm, x[n], y[n], out);
          x[n] += out[0]*dt; y[n] += out[1]*dt;
          const rr2 = x[n]*x[n] + y[n]*y[n];
          if (rr2 > rMax2){ const f = Dm.rMax/Math.sqrt(rr2); x[n] *= f; y[n] *= f; }
        }
        sand.t += dt;
      }
    },
    driftAt(n){ driftAtPoint(Dm, x[n], y[n], out); return { vx: out[0], vy: out[1] }; }
  };
  return sand;
}

const FARADAY_GRAINS = { GRAIN_MODEL, O_NEILL_WALL_SHEAR_FACTOR, floorFieldTable, floorStreaming, streamingProfile, streamingAt, streamingCoefficients,
                         columnTable, perpendicularMobility, createGrains, advanceGrains, driftMap, driftAtPoint, createSand, mulberry32 };
if (typeof module !== 'undefined' && module.exports) module.exports = FARADAY_GRAINS;
if (typeof globalThis !== 'undefined') globalThis.FARADAY_GRAINS = FARADAY_GRAINS;
