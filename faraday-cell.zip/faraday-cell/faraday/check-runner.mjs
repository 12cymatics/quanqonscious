import assert from 'node:assert/strict';
import {spawnSync} from 'node:child_process';
import {mkdtempSync,rmSync,writeFileSync} from 'node:fs';
import {tmpdir} from 'node:os';
import {join} from 'node:path';
import {runChecksSource,SUITES} from './build-zip.mjs';
const work=mkdtempSync(join(tmpdir(),'faraday-runner-check-'));
let checks=0;
function check(name,fn){fn();checks++;console.log('  ok   '+name);}
try{
  const file=join(work,'run-checks.mjs');
  writeFileSync(file,runChecksSource());
  const invoke=(...args)=>spawnSync(process.execPath,[file,...args],{cwd:work,encoding:'utf8',maxBuffer:16*1024*1024});
  check('listing names every suite and explicitly reports that no checks executed',()=>{
    const r=invoke('--list');
    assert.equal(r.status,0);
    assert.match(r.stderr,/no checks executed/);
    assert.deepEqual(r.stdout.trim().split('\n').map(s=>s.split('   ')[0]),SUITES.map(s=>s.name));
  });
  check('fast inventory names both unexecuted nonlinear suites',()=>{
    const r=invoke('--fast','--list');
    assert.equal(r.status,0);
    assert.match(r.stderr,/Not selected: .*dns\/check-cell3d\.mjs.*dns\/check-cell3d-wasm\.mjs/);
    assert.equal(r.stdout.trim().split('\n').length,SUITES.filter(s=>!s.slow).length);
  });
  check('unknown flags cannot select an unintended subset',()=>{
    const r=invoke('--nope');
    assert.equal(r.status,2);
    assert.match(r.stderr,/unknown option/);
  });
  check('the full run includes the free-contact wall compatibility requirement',()=>{
    const entry=SUITES.find(s=>s.file==='dns/check-surface-pressure.mjs');
    assert(entry);
    assert(entry.args.includes('--audit-free'));
  });
  check('absent calculation files fail every affected suite and the overall execution',()=>{
    const r=invoke();
    assert.equal(r.status,1);
    for(const s of SUITES)assert(r.stdout.includes('--- '+s.name+': FAIL'),s.name+' was not reported');
    assert(r.stdout.includes(SUITES.length+' of '+SUITES.length+' suites FAILED.'));
    assert(!/All \d+ listed suites executed and passed\./.test(r.stdout));
    assert.match(r.stdout,/Process result: exit [12]/);
  });
  check('an incomplete selection is disclosed before any selected suite executes',()=>{
    const r=invoke('--fast');
    assert.equal(r.status,1);
    assert.match(r.stderr,/INCOMPLETE selection:/);
    assert.match(r.stderr,/A partial execution cannot pass full verification/);
    assert(!/All \d+ listed suites executed and passed\./.test(r.stdout));
  });
}finally{rmSync(work,{recursive:true,force:true});}
console.log(`${checks} runner checks passed, 0 failed; no solver results claimed.`);
