# faraday-cell

## Start here

Extract the ZIP, open the faraday-cell folder, then open **index.html** in a
full desktop browser such as Safari, Chrome or Firefox. This is the complete
standalone simulator, not a link or a launcher requiring Node. No installation
is needed. A static attachment or iPhone Files preview may display the controls
without executing JavaScript; the startup notice will remain visible there.

The page now shows whether startup has reached a rendered frame, and reports
startup errors rather than leaving an unexplained blank surface.

The ZIP includes both index.html and faraday-cell-standalone.html with identical
contents. The source cymatic.html is also included, but requires the local HTTP
server described below. Running from a folder does not itself accelerate the
numerical solver. General experiment mode uses explicit physical inputs and a
pinned contact line. Select the nonlinear JavaScript or C++ engine and start the
solver explicitly. Its initialization and failures remain visible; a modal image
is not substituted while waiting for a solver frame.


A nonlinear free-surface simulation of an incompressible Newtonian liquid in a
rigid circular cell, with a pinned rim and no-slip floor and wall. Diameter,
depth, density, viscosity, surface tension, gravity and drive acceleration are
explicit inputs. The reference paper's apparatus presets and atlas are optional
comparisons. They do not determine the general experiment's nonlinear physics.

The packaged application needs a desktop browser. JavaScript checks need Node;
the exact book-derived verification needs Python 3 and SymPy 1.14.0, and rebuilding
the WebAssembly checks needs clang with the wasm32 target and lld. The application
itself does not call an external API or require those verification tools.

## Nonlinear model and corrections

`dns/MODEL.md` specifies every bulk equation and the normal, tangential,
kinematic, pinned-rim and solid-wall boundary conditions for the supported model.
It distinguishes the full nonlinear equations from their finite-grid numerical
solution. Compressible flow, a second viscous fluid, moving contact lines,
overturning interfaces and variable material properties are not silently
represented by this constant-property, single-liquid graph-surface model.

The pressure correction now includes the prescribed free-surface pressure before
the horizontal slope-transpose terms, in both JavaScript and C++. Previously a
matching constant pressure could cause spurious horizontal acceleration on a
deformed surface. `dns/check-surface-pressure.mjs` checks constant-pressure
cancellation, pressure-gauge invariance, the pinned rim and both engines.

`dns/check-book-pressure.py` uses the page-specific procedures in `vedic_book.py`
to derive exact polynomial pressure-coordinate identities. It incorporates the
book corrections recorded in PR #172 and independently checks them. Those
arithmetic checks do not turn the fluid equations or pressure projection into
sutras and do not claim physical validation.

`dns/check-book-surface.py` derives the free surface's slope, normal and
curvature exactly with the same book procedures and holds the solver's own
`curvature()`, `surfaceSlopeSquared()` and `surfaceNormal()` to them on two
manufactured surfaces. `dns/MODEL.md` states what it derives, how it decides,
and what it measured, including the pinned rim row, which does not converge.

Run the focused checks from this folder:

```
node dns/check-surface-pressure.mjs
node faraday/check-general.mjs
python3 dns/check-book-pressure.py
python3 dns/check-book-surface.py
```

## Grid update — 15 November 2026

The 3D solver refused a 325 mm × 1 mm cell at 180 Hz (gravity 3 m/s², peak
acceleration 9.8 m/s²): its grid search graded the radial cells toward the
wall with a stretch of at most 2.2, which left 0.61 cells in the wall's
Stokes layer where 2 are required. When the usual grading cannot meet that,
the search now also tries stretches of 3.0, 3.8 and 4.6, each held to the
same surface-operator and layer contract. That case now runs on 64 × 30 × 12
cells with a stretch of 3.8: 2.05 cells in the wall layer, the surface
operator to 0.93%. Every case the usual grading already met gets the same
grid as before.

That grid is sized to the seeded wave (m = 2, a third of a metre across). At
180 Hz the Faraday wavelength in that cell is about 3.8 mm, some 86
wavelengths across the dish, which no grid within 250 000 cells resolves.

## Drawing update — 11 November 2026

The modal view drew every frequency on a fixed 381-pixel grid. At 4392 Hz in
the 24.25 mm cell that is about 7 pixels per wavelength with a free rim, which
grains one pixel wide cannot show, and under 3 with a pinned rim, where the
page dropped every mode and drew a zero field without saying so.

- On a screen with a device pixel ratio of 2 or more the grid is 571 pixels
  and the grains are finer in proportion: 89 921 of them, with the same
  physical drift and agitation. On other screens nothing changes. The image
  export is unchanged on every screen.
- When no mode reaches the 4 pixels per wavelength the page draws at, the
  stage says so, with the figure, and shows no surface: for example
  `not drawn · 2.9 px/λ · 4 needed · grid 381`.
- The surface is rebuilt when its state changes, not every 0.12 s.
- Pinned-rim radial tables are built once per order for all the states that
  share it. The tables are the same to the bit. At 1500 Hz the build measured
  10.6 s before and 2.5 s after on the same machine.

Measured in Chromium at 4392 Hz, free rim, 120 grain steps from a fresh
sprinkle: the mean surface amplitude under the grains, relative to the mean
over the disc, is 0.99 fresh on both grids, 0.61 settled on the 381 grid and
0.44 settled on the 571 grid. The repository's browser startup check holds
those orderings, the grid sizes, the status line and the table identity; it
is not part of this folder.

Not changed: which modes the model selects. At 4392 Hz with a free rim it
selects m = 144, whose motion is confined near the rim, so the centre of the
dish stays unsorted on any grid. On the 571 grid a pinned rim at high
frequency builds its tables on the main thread and the page waits for them.

## Playback update — 22 October 2026

Pause/resume in the modal view now resumes from the frozen simulation time,
without adding the time spent paused. Repeated pauses and re-exciting while
paused preserve that behavior. The numerical solvers, grid selection and
accuracy settings are unchanged. This is a playback-clock correction, not a
new physics model or a speed-up of the nonlinear solver.

`node faraday/check-playback.mjs` checks the page's actual playback handlers and
clock update with controlled timestamps, including re-excite while paused.
It is a deterministic logic check, not a substitute for the real-browser suite.

The modal view is an explicitly selected visualization. The Navier–Stokes
views evolve a separate physical clock in a worker; the modal playback button
does not pause that solver. Those views can take a long time at the strict
accuracy grid. See the physical-time and wall-time readouts; do not expect
real-time fluid evolution.

## What is in here

| | |
|---|---|
| `faraday-cell-standalone.html` | **Open this first.** One file, double-click it. No server, no siblings, nothing fetched. |
| `cymatic.html` | The same page as it lives in the repository, loading its scripts from `faraday/` and `dns/`. Needs a local server (below). |
| `dns/run-cell3d.mjs` | The three-dimensional solver in a terminal, no browser: an ASCII plan view of the surface, the energy split, and the clocks. |
| `run-checks.mjs` | Runs every suite in this directory, in one command. |
| `dns/PLAN-cell3d.md` | The working record: what each stage measured, what is still open, and every expectation measurement has overturned. |

The solvers:

| | |
|---|---|
| `faraday/kernel.js` | The linear theory: Bessel modes, viscous damping, the Kumar–Tuckerman-style threshold problem, the mode map the page draws its labels from. |
| `dns/faraday-disc.js` | A two-dimensional axisymmetric Navier–Stokes solver, **one azimuthal mode at a time**, linear in the surface amplitude. Its Floquet growth rates are the reference the three-dimensional solver is measured against. |
| `dns/faraday-cell3d.js` | The three-dimensional **nonlinear** solver: every azimuthal mode at once and coupled, in a domain that follows the surface. This is what the page draws. |
| `dns/faraday_disc.cpp`, `dns/faraday_disc.wasm` | The two-dimensional solver again in C++, compiled to WebAssembly, bit for bit against the JavaScript. `dns/build-wasm.sh` rebuilds it. |
| `dns/faraday_cell3d.cpp`, `dns/faraday_cell3d.wasm` | **The three-dimensional solver in C++**, likewise compiled to WebAssembly and likewise bit for bit — operator by operator and then over a whole drive period, 894 steps at 12 × 24 × 8, every element by `Object.is`. `dns/build-wasm-cell3d.sh` rebuilds it; neither needs Emscripten, only `clang` with the wasm32 target and `lld`. |
| `dns/faraday-floquet.js`, `dns/faraday-dns.js` | The Floquet machinery and the periodic-box solver the disc one was built from. |
| `boundary/boundarykernel.js`, `fsi/coupled-affine-benchmark.js` | A boundary-condition kernel and an exact fluid–structure benchmark in rational arithmetic. |

## Running it

**The single file.** Double-click `faraday-cell-standalone.html`. The
three-dimensional solver runs in a worker; pick it under *surface drawn from*.

**The repository page.** `cymatic.html` loads its scripts by relative path and
its compiled WebAssembly by fetch, and a page opened from `file://` has no
origin a fetch can satisfy. Serve the directory instead:

```
python3 -m http.server 8000
```

then open <http://localhost:8000/cymatic.html>.

**The terminal.** No browser needed:

```
node dns/run-cell3d.mjs
node dns/run-cell3d.mjs --nr 16 --nth 32 --nz 10 --m 4 --accel 12 --periods 4
node dns/run-cell3d.mjs --engine cpp
```

Options: `nr nth nz` (grid), `m` (azimuthal mode seeded), `rel` (seed amplitude
as a fraction of the depth), `accel` and `freq` (the shaker; with no `freq` it
drives at twice the mode's own frequency, which is the subharmonic resonance
Faraday waves live on), `periods`, `frames`, `contact` (`pinned`),
`R h rho nu gamma g`, `rStretch zStretch`, `width`, `engine` (`js` or
`cpp`) and `threads`. An unknown option is refused rather than ignored.

**Threads.** The page's *solver threads* control, and `--threads N` in
`dns/run-cell3d.mjs`, spread each step's viscous and advective terms over that
many threads, the solver's own included. The page offers up to the number of
cores the browser reports and starts at one fewer, which leaves the drawing a
core. The answer is the same to the bit on any number of threads:
`dns/check-cell3d-pool.mjs` holds it to the single-threaded step with `Object.is`
on one to five workers in both engines, and `dns/check-page.mjs` replays the
page's own threaded run on one thread and compares again. What changes is the
wait, and only for the part that is divided. The pressure solve stays on one
thread: each of its iterations needs two global sums, and a page opened from a
file has no shared memory to make those cheap.

`--engine cpp` is not a faster-but-looser mode. The C++ is a transcription of the
JavaScript — same discretisation, same flux forms, same conjugate gradient with
the same tolerance and cap, same order of operations down to the grouping of each
sum, and no fused multiply-add, because an FMA rounds once where JavaScript rounds
twice. It computes no transcendental at all: the `cos` in the drive is evaluated in
JavaScript and passed in, which is what makes bit-for-bit parity achievable rather
than approximate. Measured on the container this was built on, best of three: **4.0× at
10 × 24 × 8 and 3.5× at 16 × 24 × 10**, with identical fields. If the module cannot be loaded it
refuses and says so, rather than running the JavaScript under the C++ engine's
name and reporting a time that means something else.

**The suites.**

```
node run-checks.mjs --list      # what there is
node run-checks.mjs --fast      # everything but the three-dimensional solver gate
node run-checks.mjs             # everything
```

`dns/check-cell3d.mjs` and `dns/check-cell3d-wasm.mjs` take minutes — the first
integrates the solver over many grids to measure convergence orders, the second
rebuilds the C++ and holds it to the JavaScript over a whole drive period — which
is why `--fast` exists and why those two are the only things it leaves out. `dns/check-page.mjs` drives a real Chrome over
the DevTools protocol; it **refuses** rather than skipping if it cannot find one,
and `CHROME=/path/to/chrome` tells it where to look. `faraday/check-clean.mjs` reads
the comment-free build back with [acorn](https://github.com/acornjs/acorn), a parser
independent of the one that built it, and likewise refuses without it:
`npm install --prefix /tmp/tok acorn@8.18.0`, then `ACORN=/tmp/tok/node_modules/acorn`.

`node faraday/build-clean.mjs` followed by a name for the new file writes the single
file again with every comment and every on-screen sentence taken out; the readings,
controls and solvers are the same, and both gates above hold it to that.

## Two things to know before you file a bug

**It does not run at real time, and it cannot.** On the cloud container this was
built on, a 10 × 24 × 8 grid takes 18.8 ms per step in JavaScript and 5.3 ms in
C++, and the step is set by the capillary limit: 374× slower than real time for
the first and 106× for the second, measured with `dns/run-cell3d.mjs`. On three
threads, 15.2 and 4.3 ms: 302× and 86×. (When the solver first ran on the page
those were 1278× and 489×; `dns/PLAN-cell3d.md` has what changed, under S10b, S12b
and S11.) The page shows
you the physics clock, the wall clock and their ratio rather than hiding the
gap; `dns/run-cell3d.mjs` prints the same three numbers. Your machine will give a
different ratio and the number it prints is measured on it, not estimated.

**The page's own grids are far larger than that, by design.** The page sizes its grid
for the mode it seeds, to the 1% contract below, and at the default operating point that
is 40 × 210 × 12 with a time step of 0.54 µs. Measured with `dns/run-cell3d.mjs`: 316 ms a
step in C++ and 971 ms in JavaScript, 188 and 553 ms on three threads -- about 590 000×
slower than real time in C++, so one drive period is about an hour. The fixed grid it used
to run instead was about eighty times quicker and misstated the surface's restoring force
by 4.65%.

**The physics is in double precision on the CPU, and stays there.** No GPU on an
Intel Mac has a double-precision type — Metal has no `double`, so WGSL has no
`f64` — so the GPU is used for *drawing*, where single precision is correct
because the output is an 8-bit pixel, and never for the field.

**Drawing on the GPU.** Pick **GPU** under *draw on*. The surface is then shaded by
a WebGL2 fragment shader (`faraday/render-gl.js`) instead of a per-pixel JavaScript
loop that costs 11.6–22.2 ms a frame on the CPU this was built on — more than a
whole 60 Hz frame on its own. The page remembers the choice. The deck names the
processor that drew the frame and what it cost the page. Where WebGL2 is not
available, or the browser takes the GPU's context away, drawing pauses with GPU
still selected and the line under *draw on* says why: choose CPU to draw there, or
GPU again to retry once the context is back. It never draws with the CPU under the
GPU's name, and never switches to the CPU for you.

The two are held to the same picture: `dns/check-page.mjs` draws every view both
ways, at the page's amplitude and at full amplitude in both phases, with the
texture noise off and on, and again after the field is rebuilt, and requires every
byte to agree **to within one level out of 255**. That bound is derived rather
than tuned — the inputs are identical and the two evaluations differ by parts in
ten million, which can move a byte only at a rounding boundary and only by one
level. Because a byte check alone cannot see an error smaller than one level — a
wrong coefficient that moved pixels by half a level passed it — the values
*before* rounding are compared too, against a bound of 0.02 of a level derived
from the GLSL precision rules; measured, they agree to 5×10⁻⁴. The grain simulation stays on the CPU: it draws from one seeded random
sequence in grain order, and a parallel version would be a different algorithm.

## What this is, and what it is not

Historical measurements are in `dns/PLAN-cell3d.md`, stage by stage, with the
numbers. They describe their recorded revisions and must not be treated as
fresh validation of later changes. In that record the discrete operators converge
at second order against calculus; its projection drives the divergence to the
solve tolerance; its advection telescopes exactly and conserves energy in the
inviscid limit; its curvature is the exact variational derivative of its own
discrete surface area; and at small amplitude its growth rates agree with the
two-dimensional solver next door — 2.06 against 2.09 on the driven Floquet
problem, and a quarter-period energy decay agreeing to −0.04%.

What has **not** been done, stated plainly because the list matters more than the
agreements:

- **No comparison against an experiment.** Not one.
- **No comparison against any other published code or benchmark.** Both solvers
  here were written by the same author, so their agreement rules out arithmetic
  slips and rules out nothing about a shared misconception.
- **One mode is resolved to 1%, not every mode.** The page sizes its grid for the
  mode it seeds: the surface operator within 1% on that mode, measured with this
  solver's own operator, and two cells in every Stokes layer, refusing with the
  numbers where no grid of at most 250 000 cells holds. Other modes on the same grid
  carry their own error, larger for finer patterns, and the terminal runner runs
  whatever grid it is given. The convergence studies in the suites run from
  16 × 24 × 10 to 32 × 48 × 20; at `nth = 16` the m = 5 mode reads 32.6% low there,
  which is the grid and not the physics.
- **The surface is single-valued and the solver refuses when the layer breaks.**
  No jets, no droplet pinch-off, no air entrainment, no overturning. A real cell
  driven hard does all four.
- **Open order losses are recorded, not hidden.** The surface row's accuracy is
  limited by a reconstruction whose stencil changes between adjacent columns;
  measured orders on four probes are 2.41/1.74, 1.42/1.17, 2.35/1.99 and
  2.02/1.59 where second order is wanted throughout. The pinned contact line is
  first order at the rim. Both are written up in the plan with the fix each needs.

It is not the most accurate Faraday-wave simulation in existence and nothing here
should be read as claiming that.

## The one rule the suites are built on

A test that has never been seen to fail is not known to work. Every gate in here
was proven able to fail by injecting the defect it claims to catch **on a
disposable copy**, requiring red, then removing it and requiring green — and the
record of which defect, for which gate, is in `dns/PLAN-cell3d.md`. Several of
those injections found that a gate which had been passing all along could not
see its own defect. Nothing skips, nothing is marked expected-to-fail, and no
tolerance was widened to make something green.
